class OffsetField < SignedField
  width 16
end
